#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
exec python3 "${DIR}/app.py" "$@"
