#!/usr/bin/env python3
"""
RPDevs Desktop Edition - Simon Classic
Native WebKitGTK Desktop Container
"""
import os
import sys
import threading
from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer

try:
    import gi
    gi.require_version('Gtk', '3.0')
    gi.require_version('WebKit2', '4.1')
    from gi.repository import Gtk, WebKit2, GLib
except Exception as e:
    sys.stderr.write(f"Failed to load GTK/WebKit2: {e}\n")
    sys.stderr.write("Please ensure python3-gi, gir1.2-gtk-3.0, and gir1.2-webkit2-4.1 are installed.\n")
    sys.exit(1)

ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets')
TITLE = "Simon Classic"
WIDTH = 520
HEIGHT = 720

class DualStackServer(TCPServer):
    allow_reuse_address = True

class QuietHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ASSETS_DIR, **kwargs)
    def log_message(self, format, *args):
        pass

def start_server():
    httpd = DualStackServer(('127.0.0.1', 0), QuietHandler)
    port = httpd.server_address[1]
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return port

def main():
    port = start_server()
    url = f"http://127.0.0.1:{port}/index.html"

    win = Gtk.Window(title=TITLE)
    win.set_default_size(WIDTH, HEIGHT)
    win.set_position(Gtk.WindowPosition.CENTER)

    icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon.png')
    if os.path.exists(icon_path):
        try:
            win.set_icon_from_file(icon_path)
        except Exception:
            pass

    webview = WebKit2.WebView()
    settings = webview.get_settings()
    settings.set_enable_developer_extras(False)
    settings.set_enable_webgl(True)
    settings.set_javascript_can_access_clipboard(True)
    settings.set_enable_media_stream(True)

    win.add(webview)
    webview.load_uri(url)

    win.connect('destroy', Gtk.main_quit)
    win.show_all()
    Gtk.main()

if __name__ == '__main__':
    main()
